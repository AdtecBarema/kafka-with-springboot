package com.learnkafka.domain;

public enum LibraryEventType {

    NEW,
    UPDATE
}
